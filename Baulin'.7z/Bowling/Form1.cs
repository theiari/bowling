﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace Bowling
{
    public partial class Bowling : Form
    {
        private bool tirato;
        int contatore;
        bool sweep; //variabile per far tornare giu il pintable una volta che la sbarra è ritornata in posizione iniziale
        bool b;
        int contatorePintable;
        public Bowling()
        {
            contatorePintable = 0;
            sweep = false;
            contatore = 0;
            InitializeComponent();
            pintable.BringToFront(); //mette l'immagine del pintable in primo piano
            sbarra.BringToFront(); //mette l'immagine della sbarra in primo piano
            tirato = false;
            b = false;
            
            fila1False.Visible = true; //reset immagini sensori birilli
            fila1True.Visible = false;
            fila2False.Visible = true;
            fila2True.Visible = false;
            fila3False.Visible = true;
            fila3True.Visible = false;
            fila4False.Visible = true;
            fila4True.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            sbarraBox.Text = "True";
            tirato = true;
            PallaBox.Text = "True";
            timerPalla.Enabled = true;
            MasterTimer.Enabled = true;
            tiroStrike();

        }


        private void tiroStrike()
        {
            fila1Box.Text = "True";
            fila2Box.Text = "True";
            fila3Box.Text = "True";
            fila4Box.Text = "True";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pintable.Location.Y == 380)
                contatorePintable++;    //contatore essenziale per la fase di risalita del pintable una volta rilasciati i birilli dopo lo sweep

            if (contatorePintable == 2)
            {
                timerPalla.Enabled = false;
                timerPintable.Enabled = true;
            }
            if (pintableBox.Text == "False" || pintableBox.Text == "Rising")  //se il pintable è in posizione diversa da quella in alto
            {
               
                //batteria di if che fa alzare le file di birilli rimanenti assieme al pintable
                if (fila1Box.Text == "False")
                {
                    fila1False.Top -= 10;
                }
                if (fila2Box.Text == "False")
                {
                    fila2False.Top -= 10;
                }
                if (fila3Box.Text == "False")
                {
                    fila3False.Top -= 10;
                }
                if (fila4Box.Text == "False")
                {
                    fila4False.Top -= 10;
                }



                if (pintable.Location.Y == 310) //se il pintable arriva in cima
                {
                    timerSweep.Enabled = true; //avvio procedura sweep
                    sweepBox.Text = "True";
                }

                pintable.Top -= 10;
                    pintableBox.Text = "Rising";
            }

           

           

            if ((pintableBox.Text == "True" || pintableBox.Text =="Landing") && tirato)
            {
                if (fila1False.Location.Y == 290)
                    fila1False.Top += 10;
                if (fila2False.Location.Y == 290)
                    fila2False.Top += 10;
                if (fila3False.Location.Y == 290)
                    fila3False.Top += 10;
                if (fila4False.Location.Y == 290)
                    fila4False.Top += 10;

                pintable.Top += 10;
                pintableBox.Text = "Landing";
                
            }

            
               if (sbarraBox.Text == "False" && PallaBox.Text == "True")
            {
                sbarra.Top += 100;
                PallaBox.Text = "False";

               
            }

             if (sweep && pintableBox.Text != "False")//quando la sbarra ha finito di fare il movimento
            {
                if (fila1False.Enabled == true)
                    fila1False.Top += 10;
                if (fila2False.Enabled == true)
                    fila2False.Top += 10;
                if (fila3False.Enabled == true)
                    fila3False.Top += 10;
                if (fila4False.Enabled == true)
                    fila4False.Top += 10;

                pintable.Top += 10;
                pintableBox.Text = "Landing";

            }

            else
            {
                sweep = false;
                //if (pintableBox.Text != "False") {
                //   pintable.Top -= 10;
                // pintableBox.Text = "Rising";
                //}
            }
        }

        

        private void timerSweep_Tick(object sender, EventArgs e) //spostamento della sbarra/sweep
        {
            if (contatore < 35) //se la sbarra non sta a sinistra e il bool è falso vai a sinistra
            {   
                sbarra.Left -= 10; // un numero <0 implica uno spostamento verso sinistra
                contatore++;
            }
            else
            {
                contatore++;
                sbarra.Left += 10;
                if (contatore == 70) //la sbarra torna in posizione iniziale
                {
                    contatore = 0;
                    timerSweep.Enabled = false;
                    sweep = true;
                    sweepBox.Text = "False";
                    sbarraBox.Text = "False";
                }
            }
            //   if (b && sbarra.Location.X == 435)
            //        sbarra.Left += 10;                  // un numero >0 implica uno spostamento verso destra
            //    }

        }

        private void timerPintable_Tick(object sender, EventArgs e) //questo timer parte quando il pintable poggia i birrilli per terra, successivamente allo sweep
        {
            pintable.Top -= 10;
            pintableBox.Text = "Rising";
            if (pintable.Location.Y == 300)
            {
                timerPintable.Enabled = false;   
                contatorePintable = 0;
                sbarra.Location = new Point(445, 290);
                primoTiroTextbox.Text = "False";
            }
           
        }

        private void MasterTimer_Tick(object sender, EventArgs e)
        {
            if (pintable.Location.Y == 300)
                pintableBox.Text = "True"; //posizione sollevata
            if (pintable.Location.Y == 380)
            {
                pintableBox.Text = "False"; //posizione abbassata
                tirato = false;
            }

            if (sbarra.Location.Y == 290)
                sbarraBox.Text = "False";
            if (sbarra.Location.Y == 390)
                sbarraBox.Text = "True";

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void fila1Box_TextChanged(object sender, EventArgs e)
        {
            

            if (fila1Box.Text == "True")
            {
                fila1False.Visible = false;
                fila1True.Visible = true;
            }
            if (fila1Box.Text == "False")
            {
                fila1False.Visible = true;
                fila1True.Visible = false;
            }

        }

        private void fila2Box_TextChanged(object sender, EventArgs e)
        {
            if (fila2Box.Text == "True")
            {
                fila2False.Visible = false;
                fila2True.Visible = true;
            }
            if (fila2Box.Text == "False")
            {
                fila2False.Visible = true;
                fila2True.Visible = false;
            }
        }

                private void fila4Box_TextChanged(object sender, EventArgs e)
        {
            if (fila4Box.Text == "True")
            {
                fila4False.Visible = false;
                fila4True.Visible = true;
            }
            if (fila4Box.Text == "False")
            {
                fila4False.Visible = true;
                fila4True.Visible = false;
            }
        }

        // bottone RESET
        private void button2_Click(object sender, EventArgs e)
        {
            tirato = false;
            b = false;
            contatore = 0;
            sweep = false;
            contatorePintable = 0;
            primoTiroTextbox.Text = "True";

            Point p = new Point(143, 300);  //reset posizione pintable
            pintable.Location = p;
            pintableBox.Text = "True";

            Point s = new Point(445, 290); //reset posizione sbarra
            sbarra.Location = s;
            sbarraBox.Text = "False";

            fila1Box.Text = "False";  //reset sensori birilli
            fila2Box.Text = "False";
            fila3Box.Text = "False";
            fila4Box.Text = "False";

            PallaBox.Text = "False";   //reset sensori pista
            sbarraBox.Text = "False";
            sweepBox.Text = "False";

            MasterTimer.Enabled = false; //reset timers
            timerPalla.Enabled = false;
            timerPintable.Enabled = false;
            timerSweep.Enabled = false;


            fila1False.Visible = true; //reset immagini sensori birilli
            fila1True.Visible = false;
            fila2False.Visible = true;
            fila2True.Visible = false;
            fila3False.Visible = true;
            fila3True.Visible = false;
            fila4False.Visible = true;
            fila4True.Visible = false;

            fila1False.Location = new Point(338, 370); //reset posizione birillo
            fila2False.Location = new Point(283, 370);
            fila3False.Location = new Point(227, 370);
            fila4False.Location = new Point(172, 370);

            PallaBox.Text = "False"; //reset immagine sensore palla
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void fila3Box_TextChanged_1(object sender, EventArgs e)
        {
            if (fila3Box.Text == "True")
            {
                fila3False.Visible = false;
                fila3True.Visible = true;
            }
            if (fila3Box.Text == "False")
            {
                fila3False.Visible = true;
                fila3True.Visible = false;
            }
        }

        private void fila4Box_TextChanged_1(object sender, EventArgs e)
        {
            if (fila4Box.Text == "True")
            {
                fila4False.Visible = false;
                fila4True.Visible = true;
            }
            if (fila4Box.Text == "False")
            {
                fila4False.Visible = true;
                fila4True.Visible = false;
            }
        }

        private void pintableBox_TextChanged(object sender, EventArgs e)
        {
            if ((pintableBox.Text != "Landing" || pintableBox.Text != "Rising") && pintable.Location.Y != 310 && pintable.Location.Y != 370)
                

            if (pintableBox.Text == "True" && b)
                sbarra.Location = new Point(445, 290);
            
           
        }

        private void sbarraBox_TextChanged(object sender, EventArgs e)
        {
                     //attiva il movimento orizzontale della sbarra
        }

        //tiro mediocre
        

        private void button3_Click_1(object sender, EventArgs e)
        {
            Random fila = new Random();
            int birilli = fila.Next(1, 4);

            sbarraBox.Text = "True";
            tirato = true;
            PallaBox.Text = "True";
            timerPalla.Enabled = true;
            MasterTimer.Enabled = true;

            if (birilli == 1)
            {
                fila1Box.Text = "True";
            }
            else if (birilli == 2)
            {
                fila1Box.Text = "True";
                fila2Box.Text = "True";
            }
            else if (birilli == 3)
            {
                fila1Box.Text = "True";
                fila2Box.Text = "True";
                fila3Box.Text = "True";

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sbarraBox.Text = "True";
            tirato = true;
            PallaBox.Text = "True";
            timerPalla.Enabled = true;
            MasterTimer.Enabled = true;
        }

        private void sweepBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void PallaBox_TextChanged(object sender, EventArgs e)
        {
            if (PallaBox.Text == "True")
            {
                sensorePallaFalse.Visible = false;
                sensorePallaTrue.Visible = true;
            }
            if (PallaBox.Text == "False")
            {
                sensorePallaTrue.Visible = false;
                sensorePallaFalse.Visible = true;
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
