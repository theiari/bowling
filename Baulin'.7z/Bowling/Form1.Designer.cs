﻿
namespace Bowling
{
    partial class Bowling
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bowling));
            this.button1 = new System.Windows.Forms.Button();
            this.PallaBox = new System.Windows.Forms.TextBox();
            this.timerPalla = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pintableBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.sweepBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.sbarraBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.primoTiroTextbox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.fila4Box = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.fila3Box = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.fila2Box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.fila1Box = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.timerSweep = new System.Windows.Forms.Timer(this.components);
            this.timerPintable = new System.Windows.Forms.Timer(this.components);
            this.MasterTimer = new System.Windows.Forms.Timer(this.components);
            this.pintable = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.sbarra = new System.Windows.Forms.PictureBox();
            this.fila4False = new System.Windows.Forms.PictureBox();
            this.fila4True = new System.Windows.Forms.PictureBox();
            this.fila3False = new System.Windows.Forms.PictureBox();
            this.fila3True = new System.Windows.Forms.PictureBox();
            this.fila2False = new System.Windows.Forms.PictureBox();
            this.fila1True = new System.Windows.Forms.PictureBox();
            this.fila1False = new System.Windows.Forms.PictureBox();
            this.fila2True = new System.Windows.Forms.PictureBox();
            this.sensorePallaTrue = new System.Windows.Forms.PictureBox();
            this.sensorePallaFalse = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pintable)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sbarra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila4False)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila4True)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila3False)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila3True)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila2False)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila1True)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila1False)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila2True)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sensorePallaTrue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sensorePallaFalse)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 26);
            this.button1.TabIndex = 0;
            this.button1.Text = "tiro Strike";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PallaBox
            // 
            this.PallaBox.Location = new System.Drawing.Point(114, 12);
            this.PallaBox.Name = "PallaBox";
            this.PallaBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.PallaBox.Size = new System.Drawing.Size(100, 23);
            this.PallaBox.TabIndex = 1;
            this.PallaBox.Text = "False";
            this.PallaBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PallaBox.TextChanged += new System.EventHandler(this.PallaBox_TextChanged);
            // 
            // timerPalla
            // 
            this.timerPalla.Interval = 200;
            this.timerPalla.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pintableBox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.sweepBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.sbarraBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.PallaBox);
            this.panel1.Location = new System.Drawing.Point(466, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(232, 167);
            this.panel1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(20, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Pintable";
            // 
            // pintableBox
            // 
            this.pintableBox.Location = new System.Drawing.Point(114, 125);
            this.pintableBox.Name = "pintableBox";
            this.pintableBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pintableBox.Size = new System.Drawing.Size(100, 23);
            this.pintableBox.TabIndex = 7;
            this.pintableBox.Text = "True";
            this.pintableBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pintableBox.TextChanged += new System.EventHandler(this.pintableBox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(20, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Sweep";
            // 
            // sweepBox
            // 
            this.sweepBox.Location = new System.Drawing.Point(114, 88);
            this.sweepBox.Name = "sweepBox";
            this.sweepBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sweepBox.Size = new System.Drawing.Size(100, 23);
            this.sweepBox.TabIndex = 5;
            this.sweepBox.Text = "False";
            this.sweepBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.sweepBox.TextChanged += new System.EventHandler(this.sweepBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(20, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sbarra";
            // 
            // sbarraBox
            // 
            this.sbarraBox.Location = new System.Drawing.Point(114, 50);
            this.sbarraBox.Name = "sbarraBox";
            this.sbarraBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sbarraBox.Size = new System.Drawing.Size(100, 23);
            this.sbarraBox.TabIndex = 3;
            this.sbarraBox.Text = "False";
            this.sbarraBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.sbarraBox.TextChanged += new System.EventHandler(this.sbarraBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(20, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Palla";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.primoTiroTextbox);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.fila4Box);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.fila3Box);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.fila2Box);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.fila1Box);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(236, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(214, 167);
            this.panel2.TabIndex = 3;
            // 
            // primoTiroTextbox
            // 
            this.primoTiroTextbox.Location = new System.Drawing.Point(97, 128);
            this.primoTiroTextbox.Name = "primoTiroTextbox";
            this.primoTiroTextbox.Size = new System.Drawing.Size(100, 23);
            this.primoTiroTextbox.TabIndex = 7;
            this.primoTiroTextbox.Text = "True";
            this.primoTiroTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(18, 128);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 20);
            this.label13.TabIndex = 6;
            this.label13.Text = "Primo tiro";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // fila4Box
            // 
            this.fila4Box.Location = new System.Drawing.Point(97, 99);
            this.fila4Box.Name = "fila4Box";
            this.fila4Box.Size = new System.Drawing.Size(100, 23);
            this.fila4Box.TabIndex = 5;
            this.fila4Box.Text = "False";
            this.fila4Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fila4Box.TextChanged += new System.EventHandler(this.fila4Box_TextChanged_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(18, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Fila 4";
            // 
            // fila3Box
            // 
            this.fila3Box.Location = new System.Drawing.Point(97, 70);
            this.fila3Box.Name = "fila3Box";
            this.fila3Box.Size = new System.Drawing.Size(100, 23);
            this.fila3Box.TabIndex = 5;
            this.fila3Box.Text = "False";
            this.fila3Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fila3Box.TextChanged += new System.EventHandler(this.fila3Box_TextChanged_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(18, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "Fila 3";
            // 
            // fila2Box
            // 
            this.fila2Box.Location = new System.Drawing.Point(97, 41);
            this.fila2Box.Name = "fila2Box";
            this.fila2Box.Size = new System.Drawing.Size(100, 23);
            this.fila2Box.TabIndex = 3;
            this.fila2Box.Text = "False";
            this.fila2Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fila2Box.TextChanged += new System.EventHandler(this.fila2Box_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(18, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Fila 2";
            // 
            // fila1Box
            // 
            this.fila1Box.Location = new System.Drawing.Point(97, 12);
            this.fila1Box.Name = "fila1Box";
            this.fila1Box.Size = new System.Drawing.Size(100, 23);
            this.fila1Box.TabIndex = 1;
            this.fila1Box.Text = "False";
            this.fila1Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fila1Box.TextChanged += new System.EventHandler(this.fila1Box_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(18, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Fila 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(294, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 20);
            this.label9.TabIndex = 4;
            this.label9.Text = "Sensori Birilli";
            // 
            // timerSweep
            // 
            this.timerSweep.Interval = 60;
            this.timerSweep.Tick += new System.EventHandler(this.timerSweep_Tick);
            // 
            // timerPintable
            // 
            this.timerPintable.Interval = 200;
            this.timerPintable.Tick += new System.EventHandler(this.timerPintable_Tick);
            // 
            // MasterTimer
            // 
            this.MasterTimer.Interval = 1;
            this.MasterTimer.Tick += new System.EventHandler(this.MasterTimer_Tick);
            // 
            // pintable
            // 
            this.pintable.Image = ((System.Drawing.Image)(resources.GetObject("pintable.Image")));
            this.pintable.Location = new System.Drawing.Point(143, 300);
            this.pintable.Name = "pintable";
            this.pintable.Size = new System.Drawing.Size(288, 34);
            this.pintable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pintable.TabIndex = 5;
            this.pintable.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(538, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 20);
            this.label10.TabIndex = 10;
            this.label10.Text = "Sensori Pista";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(11, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 26);
            this.button2.TabIndex = 11;
            this.button2.Text = "RESET";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(109, 11);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 26);
            this.button3.TabIndex = 12;
            this.button3.Text = "tiro mediocre";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(109, 43);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(92, 26);
            this.button4.TabIndex = 13;
            this.button4.Text = "tiro a vuoto";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.button4);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Location = new System.Drawing.Point(21, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(209, 79);
            this.panel4.TabIndex = 14;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(93, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 20);
            this.label11.TabIndex = 15;
            this.label11.Text = "Comandi";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // sbarra
            // 
            this.sbarra.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.sbarra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.sbarra.Image = ((System.Drawing.Image)(resources.GetObject("sbarra.Image")));
            this.sbarra.InitialImage = ((System.Drawing.Image)(resources.GetObject("sbarra.InitialImage")));
            this.sbarra.Location = new System.Drawing.Point(445, 290);
            this.sbarra.Margin = new System.Windows.Forms.Padding(0);
            this.sbarra.Name = "sbarra";
            this.sbarra.Size = new System.Drawing.Size(139, 82);
            this.sbarra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sbarra.TabIndex = 16;
            this.sbarra.TabStop = false;
            // 
            // fila4False
            // 
            this.fila4False.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila4False.Image = ((System.Drawing.Image)(resources.GetObject("fila4False.Image")));
            this.fila4False.Location = new System.Drawing.Point(172, 370);
            this.fila4False.Name = "fila4False";
            this.fila4False.Size = new System.Drawing.Size(79, 105);
            this.fila4False.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila4False.TabIndex = 24;
            this.fila4False.TabStop = false;
            // 
            // fila4True
            // 
            this.fila4True.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila4True.Image = ((System.Drawing.Image)(resources.GetObject("fila4True.Image")));
            this.fila4True.Location = new System.Drawing.Point(172, 371);
            this.fila4True.Name = "fila4True";
            this.fila4True.Size = new System.Drawing.Size(79, 105);
            this.fila4True.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila4True.TabIndex = 20;
            this.fila4True.TabStop = false;
            // 
            // fila3False
            // 
            this.fila3False.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila3False.Image = ((System.Drawing.Image)(resources.GetObject("fila3False.Image")));
            this.fila3False.Location = new System.Drawing.Point(227, 370);
            this.fila3False.Name = "fila3False";
            this.fila3False.Size = new System.Drawing.Size(79, 105);
            this.fila3False.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila3False.TabIndex = 23;
            this.fila3False.TabStop = false;
            // 
            // fila3True
            // 
            this.fila3True.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila3True.Image = ((System.Drawing.Image)(resources.GetObject("fila3True.Image")));
            this.fila3True.Location = new System.Drawing.Point(227, 371);
            this.fila3True.Name = "fila3True";
            this.fila3True.Size = new System.Drawing.Size(79, 105);
            this.fila3True.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila3True.TabIndex = 19;
            this.fila3True.TabStop = false;
            // 
            // fila2False
            // 
            this.fila2False.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila2False.Image = ((System.Drawing.Image)(resources.GetObject("fila2False.Image")));
            this.fila2False.Location = new System.Drawing.Point(283, 370);
            this.fila2False.Name = "fila2False";
            this.fila2False.Size = new System.Drawing.Size(79, 105);
            this.fila2False.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila2False.TabIndex = 22;
            this.fila2False.TabStop = false;
            // 
            // fila1True
            // 
            this.fila1True.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila1True.Image = ((System.Drawing.Image)(resources.GetObject("fila1True.Image")));
            this.fila1True.Location = new System.Drawing.Point(338, 370);
            this.fila1True.Name = "fila1True";
            this.fila1True.Size = new System.Drawing.Size(79, 105);
            this.fila1True.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila1True.TabIndex = 17;
            this.fila1True.TabStop = false;
            this.fila1True.Visible = false;
            // 
            // fila1False
            // 
            this.fila1False.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila1False.Image = ((System.Drawing.Image)(resources.GetObject("fila1False.Image")));
            this.fila1False.Location = new System.Drawing.Point(338, 371);
            this.fila1False.Name = "fila1False";
            this.fila1False.Size = new System.Drawing.Size(79, 105);
            this.fila1False.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila1False.TabIndex = 21;
            this.fila1False.TabStop = false;
            // 
            // fila2True
            // 
            this.fila2True.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fila2True.Image = ((System.Drawing.Image)(resources.GetObject("fila2True.Image")));
            this.fila2True.Location = new System.Drawing.Point(283, 371);
            this.fila2True.Name = "fila2True";
            this.fila2True.Size = new System.Drawing.Size(79, 105);
            this.fila2True.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fila2True.TabIndex = 18;
            this.fila2True.TabStop = false;
            // 
            // sensorePallaTrue
            // 
            this.sensorePallaTrue.Image = ((System.Drawing.Image)(resources.GetObject("sensorePallaTrue.Image")));
            this.sensorePallaTrue.InitialImage = ((System.Drawing.Image)(resources.GetObject("sensorePallaTrue.InitialImage")));
            this.sensorePallaTrue.Location = new System.Drawing.Point(607, 401);
            this.sensorePallaTrue.Name = "sensorePallaTrue";
            this.sensorePallaTrue.Size = new System.Drawing.Size(60, 106);
            this.sensorePallaTrue.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sensorePallaTrue.TabIndex = 25;
            this.sensorePallaTrue.TabStop = false;
            // 
            // sensorePallaFalse
            // 
            this.sensorePallaFalse.Image = ((System.Drawing.Image)(resources.GetObject("sensorePallaFalse.Image")));
            this.sensorePallaFalse.InitialImage = ((System.Drawing.Image)(resources.GetObject("sensorePallaFalse.InitialImage")));
            this.sensorePallaFalse.Location = new System.Drawing.Point(607, 401);
            this.sensorePallaFalse.Name = "sensorePallaFalse";
            this.sensorePallaFalse.Size = new System.Drawing.Size(60, 106);
            this.sensorePallaFalse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sensorePallaFalse.TabIndex = 26;
            this.sensorePallaFalse.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(368, 481);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 21);
            this.label12.TabIndex = 27;
            this.label12.Text = "1ª";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(313, 481);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 21);
            this.label14.TabIndex = 28;
            this.label14.Text = "2ª";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(255, 481);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 21);
            this.label15.TabIndex = 29;
            this.label15.Text = "3ª";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(197, 481);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 21);
            this.label16.TabIndex = 30;
            this.label16.Text = "4ª";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(143, 482);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 20);
            this.label17.TabIndex = 31;
            this.label17.Text = "Fila:";
            // 
            // Bowling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(732, 511);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.sensorePallaFalse);
            this.Controls.Add(this.sensorePallaTrue);
            this.Controls.Add(this.fila4False);
            this.Controls.Add(this.fila4True);
            this.Controls.Add(this.fila3False);
            this.Controls.Add(this.fila3True);
            this.Controls.Add(this.fila2False);
            this.Controls.Add(this.fila1True);
            this.Controls.Add(this.fila1False);
            this.Controls.Add(this.fila2True);
            this.Controls.Add(this.sbarra);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pintable);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Bowling";
            this.Text = "Bowling";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pintable)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sbarra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila4False)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila4True)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila3False)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila3True)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila2False)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila1True)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila1False)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fila2True)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sensorePallaTrue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sensorePallaFalse)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox PallaBox;
        private System.Windows.Forms.Timer timerPalla;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox sweepBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sbarraBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox pintableBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox fila4Box;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox fila3Box;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox fila2Box;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox fila1Box;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Timer timerSweep;
        private System.Windows.Forms.Timer timerPintable;
        private System.Windows.Forms.Timer MasterTimer;
        private System.Windows.Forms.PictureBox pintable;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox sbarra;
        private System.Windows.Forms.PictureBox fila4False;
        private System.Windows.Forms.PictureBox fila4True;
        private System.Windows.Forms.PictureBox fila3False;
        private System.Windows.Forms.PictureBox fila3True;
        private System.Windows.Forms.PictureBox fila2False;
        private System.Windows.Forms.PictureBox fila1True;
        private System.Windows.Forms.PictureBox fila1False;
        private System.Windows.Forms.PictureBox fila2True;
        private System.Windows.Forms.PictureBox sensorePallaTrue;
        private System.Windows.Forms.PictureBox sensorePallaFalse;
        private System.Windows.Forms.TextBox primoTiroTextbox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
    }
}

